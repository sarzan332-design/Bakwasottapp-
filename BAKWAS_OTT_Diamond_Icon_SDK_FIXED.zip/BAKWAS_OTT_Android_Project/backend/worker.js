/**
 * Cloudflare Worker starter for admin-only Bunny Stream upload video creation.
 * Configure BUNNY_LIBRARY_ID, BUNNY_API_KEY, ADMIN_TOKEN as Worker secrets.
 * POST /admin/create-upload with Authorization: Bearer <ADMIN_TOKEN>
 */
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const cors = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
      "Content-Type": "application/json"
    };
    if (request.method === "OPTIONS") return new Response(null, { headers: cors });
    if (url.pathname !== "/admin/create-upload" || request.method !== "POST") {
      return new Response(JSON.stringify({ error: "Not found" }), { status: 404, headers: cors });
    }
    const auth = request.headers.get("Authorization") || "";
    if (!env.ADMIN_TOKEN || auth !== `Bearer ${env.ADMIN_TOKEN}`) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: cors });
    }
    if (!env.BUNNY_LIBRARY_ID || !env.BUNNY_API_KEY) {
      return new Response(JSON.stringify({ error: "Backend secrets are not configured" }), { status: 500, headers: cors });
    }
    let body;
    try { body = await request.json(); } catch {
      return new Response(JSON.stringify({ error: "Invalid JSON" }), { status: 400, headers: cors });
    }
    const title = String(body.title || "").trim().slice(0, 200);
    if (!title) return new Response(JSON.stringify({ error: "title is required" }), { status: 400, headers: cors });

    const response = await fetch(`https://video.bunnycdn.com/library/${env.BUNNY_LIBRARY_ID}/videos`, {
      method: "POST",
      headers: { "AccessKey": env.BUNNY_API_KEY, "Content-Type": "application/json", "Accept": "application/json" },
      body: JSON.stringify({ title })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      return new Response(JSON.stringify({ error: "Bunny API request failed", details: data }), { status: 502, headers: cors });
    }
    // Return video ID only. Upload URL and subsequent upload process must be implemented by the trusted admin client.
    return new Response(JSON.stringify({ videoId: data.guid, title }), { status: 201, headers: cors });
  }
};
