# BAKWAS secure upload backend (Cloudflare Worker starter)

Bunny Stream pricing: https://bunny.net/pricing/stream/

## Required setup
1. Create a Bunny Stream video library.
2. Create a Cloudflare Worker.
3. Add Worker secrets (never put them in the Android app):
   - `BUNNY_LIBRARY_ID`
   - `BUNNY_API_KEY`
   - `ADMIN_TOKEN`
4. Deploy `worker.js`.
5. The app still needs to call this Worker and a database/catalogue needs to be connected before the Admin Panel is functional.

## Security notes
This starter uses a single bearer admin token as a minimal gate. For production, use proper admin authentication, token rotation, rate limits, audit logs, and a database. Never embed `BUNNY_API_KEY` in an APK.
