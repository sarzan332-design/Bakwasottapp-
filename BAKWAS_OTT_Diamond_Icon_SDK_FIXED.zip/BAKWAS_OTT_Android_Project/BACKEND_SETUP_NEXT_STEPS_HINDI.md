# BAKWAS OTT — अगला backend setup

## दिए गए public/project settings
- Supabase Project URL: `https://mykygfjrjjsmwdforljj.supabase.co`
- Supabase Publishable key: `sb_publishable_2EjEascVirQ_B0JWUhjQ9w_d8wnmVff`
- Cloudinary cloud name: `qarcxthn`
- Cloudinary upload preset: `bakwas_ott_upload`

## जरूरी स्थिति
इस ZIP में diamond artwork को Android launcher app icon के रूप में जोड़ा गया है।
Supabase database/auth और Cloudinary upload अभी app code में wired/functional नहीं हैं।
अगले चरण में Supabase SDK, database queries, admin authentication और secure Cloudinary
upload flow लागू करने होंगे। Cloudinary API Secret / Supabase secret/service-role key
कभी Android app या GitHub repository में न डालें.
