package com.bakwas.ott

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF101014)
private val Panel = Color(0xFF1D1D24)
private val Red = Color(0xFFE53935)
private val Soft = Color(0xFFB9B9C2)

data class Episode(val title: String, val description: String, val season: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BakwasApp() }
    }
}

@Composable
fun BakwasApp() {
    var selected by remember { mutableStateOf<Episode?>(null) }
    var search by remember { mutableStateOf("") }
    val episodes = listOf(
        Episode("Roommates Ka Raita", "Do doston ki daily life aur comedy ka hungama.", "Season 1 • Episode 1"),
        Episode("Shaadi Mein Bawaal", "Ek wedding plan jo bilkul ulta pad gaya.", "Season 1 • Episode 2"),
        Episode("Mohalle Ka Superstar", "Mohalle mein fame paane ki funny koshish.", "Season 1 • Episode 3")
    )
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Red, background = Ink, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Surface(Modifier.fillMaxSize(), color = Ink) {
            if (selected == null) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().background(Ink),
                    contentPadding = PaddingValues(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("BAKWAS", fontSize = 31.sp, fontWeight = FontWeight.Black, color = Red)
                                Text("COMEDY • DRAMA • ENTERTAINMENT", fontSize = 10.sp, color = Soft, letterSpacing = 1.sp)
                            }
                            Icon(Icons.Default.Search, contentDescription = "Search", tint = Color.White)
                        }
                    }
                    item {
                        Box(
                            Modifier.fillMaxWidth().height(175.dp)
                                .background(Panel, RoundedCornerShape(18.dp)).padding(18.dp),
                            contentAlignment = Alignment.BottomStart
                        ) {
                            Column {
                                Text("NAYA EPISODE. NAYA BAWAAL.", color = Red, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(6.dp))
                                Text("Har kahani mein kuch na kuch BAKWAS hai!", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                                Text("Original Comedy-Drama Series", color = Soft, fontSize = 12.sp)
                            }
                        }
                    }
                    item {
                        OutlinedTextField(
                            value = search, onValueChange = { search = it },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("Series ya episode search karein") },
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp)
                        )
                    }
                    item { Text("Trending Episodes", fontSize = 20.sp, fontWeight = FontWeight.Bold) }
                    items(episodes.filter { it.title.contains(search, ignoreCase = true) }) { ep ->
                        EpisodeCard(ep) { selected = ep }
                    }
                    item {
                        Text("Categories", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("Comedy", "Drama", "Web Series").forEach {
                                AssistChip(onClick = {}, label = { Text(it) })
                            }
                        }
                    }
                    item {
                        Text("Admin upload, login aur real online catalogue backend connect karne ke baad enable honge.",
                            color = Soft, fontSize = 12.sp)
                    }
                }
            } else {
                Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("‹  Back", color = Red, modifier = Modifier.clickable { selected = null })
                    Text(selected!!.title, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Text(selected!!.season, color = Red)
                    Text(selected!!.description, color = Soft)
                    Box(Modifier.fillMaxWidth().height(190.dp).background(Panel, RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = Red, modifier = Modifier.size(68.dp))
                    }
                    Text("Video playback ke liye Bunny Stream playback ID / HLS URL aur player integration configure karna hoga.", color = Soft)
                    Button(onClick = { selected = null }) { Text("Back to Home") }
                }
            }
        }
    }
}

@Composable
fun EpisodeCard(ep: Episode, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp))
            .clickable { onClick() }.padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(width = 104.dp, height = 78.dp).background(Color(0xFF34343D), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.PlayArrow, contentDescription = "Play episode", tint = Red, modifier = Modifier.size(34.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(ep.title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(ep.season, color = Red, fontSize = 11.sp)
            Text(ep.description, color = Soft, fontSize = 12.sp, maxLines = 2)
        }
    }
}
