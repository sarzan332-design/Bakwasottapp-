# BAKWAS OTT — Android starter project

यह एक शुरुआती Android OTT प्रोजेक्ट है। इसमें Home screen, Series/Season/Episode का बेसिक ढाँचा, video player screen और GitHub Actions APK build workflow शामिल हैं।

## वीडियो बैकएंड
इस प्रोजेक्ट के लिए कम लागत वाला विकल्प **Bunny Stream** चुना गया है। इसकी आधिकारिक pricing के अनुसार storage और delivery usage के हिसाब से बिल होते हैं और $1 monthly minimum दिखाया गया है। कीमत/क्षेत्र के हिसाब से बदलाव हो सकते हैं:
https://bunny.net/pricing/stream/

## महत्वपूर्ण: यह अभी पूरा production OTT नहीं है
- APK का UI starter है; production login, database, comments, watch history और notifications को जोड़ना बाकी है।
- Admin-only upload सुरक्षित रखने के लिए Bunny API key Android app में नहीं रखी जाती। उसे server-side backend/Cloudflare Worker में secret के रूप में रखना होगा।
- इस ZIP में `backend/worker.js` एक शुरुआती Cloudflare Worker example है। इसे deploy करने और Bunny Stream credentials जोड़ने के बाद ही secure upload link बनाया जा सकेगा।
- कोई credentials इस ZIP में शामिल नहीं हैं।
- Android फोन पर ZIP extract करने की जरूरत नहीं: ZIP को GitHub repository में upload करना हो तो GitHub web UI ZIP को अपने-आप project files में नहीं बदलता। नीचे दिए गए workflow में ZIP को repository में `BAKWAS_OTT_Android_Project.zip` नाम से रखें; workflow server पर उसे extract करके APK build करता है।

## GitHub Actions से APK
1. GitHub repository बनाएं।
2. इस ZIP को repository में `BAKWAS_OTT_Android_Project.zip` नाम से upload करें।
3. इस ZIP के अंदर मौजूद `.github/workflows/build-apk.yml` को repository की `.github/workflows/build-apk.yml` जगह पर भी रखें। (GitHub workflow file को पहचानने के लिए उसे repository में सीधे `.github/workflows/` के नीचे होना चाहिए।)
4. Actions tab → **Build BAKWAS OTT APK** → Run workflow.
5. Build सफल होने पर `BAKWAS-OTT-debug-apk` artifact डाउनलोड करें।

यदि repository में ZIP को सिर्फ upload किया है, तो workflow server पर ZIP extract करेगा। GitHub Actions workflow को पहले से `.github/workflows/` में मौजूद होना आवश्यक है।

## Backend setup
`backend/README.md` पढ़ें। Cloudflare Worker secrets:
- `BUNNY_LIBRARY_ID`
- `BUNNY_API_KEY`
- `ADMIN_TOKEN`

`ADMIN_TOKEN` एक लंबा random secret रखें। इसे सार्वजनिक रूप से साझा न करें।
